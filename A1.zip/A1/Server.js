/**
* WEB322 - Assignment 1
* I declare that this assignment is my own work in accordance
with Seneca Academic Policy.
* No part of this assignment has been copied manually or
electronically from any other source
* (including web sites, friends gpt or otherwise) or
distributed to other students.
* I understand that if caught doing so, I will receive zero on
this assignment and possibly
* fail the entire course.
* Name: Darshan Kalpeshbhai Prajapati
* Student ID: 112908215
* Date: 17th May 2024
* Vercel Web App URL:
* GitHub Repository URL: https://github.com/Darshannnnnnnnnn/WEB322
**/

console.log("Darshan Kalpeshbhai Prajapati - 112908215");